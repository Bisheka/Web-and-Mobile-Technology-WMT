/*
Student ID: IT24102555
Name: weerathunga B.A
*/

document.addEventListener("DOMContentLoaded", function () {
   
    const pageTitle = document.getElementById("pageTitle");
    const libraryImage = document.getElementById("libraryImage");
    const seatTable = document.getElementById("seatTable");
 
    const bookingForm = document.getElementById("bookingForm");
    const studentName = document.getElementById("studentName");
    const studentEmail = document.getElementById("studentEmail");
    const bookingTable = document.getElementById("bookingTable");
 
    // Task 1
    document.title = "Library Seat Booking – DOM Test";
    console.log("Page URL:", window.location.href);
 
    // Task 2
    pageTitle.style.color = "green";
    pageTitle.style.fontSize = "34px";
 
    setTimeout(function () {
      document.body.style.backgroundColor = "#D3D3D3";
    }, 2000);
 
    //Task 3
    libraryImage.addEventListener("mouseover", function () {
      libraryImage.style.border = "5px solid blue";
    });
 
    libraryImage.addEventListener("mouseout", function () {
      libraryImage.style.border = "none";
    });
 
    seatTable.addEventListener("click", function () {
      alert("You clicked on the Seat Categories table!");
    });
 
    //Task 4
    studentName.addEventListener("keyup", function () {
      studentName.style.backgroundColor = "yellow";
    });
 
    window.addEventListener("resize", function () {
      console.log("Window resized");
    });
 
    //Task 5
    const originalSrc = libraryImage.getAttribute("src");
 
    const preloadImg = new Image();
    preloadImg.src = "./images/image_2.jpeg";
 
    let swapped = false;
 
    libraryImage.addEventListener("dblclick", function () {
      if (!swapped) {
        libraryImage.setAttribute("src", preloadImg.src);
        swapped = true;
      } else {
        libraryImage.setAttribute("src", originalSrc);
        swapped = false;
      }
    });
 
    //Task 6
    bookingForm.addEventListener("submit", function (event) {
      event.preventDefault(); // prevent refresh
 
      const name = studentName.value.trim();
      const email = studentEmail.value.trim();
 
      // Create new row
      const tr = document.createElement("tr");
 
      const tdName = document.createElement("td");
      tdName.textContent = name;
 
      const tdEmail = document.createElement("td");
      tdEmail.textContent = email;
 
      const tdAction = document.createElement("td");
      const deleteBtn = document.createElement("button");
      deleteBtn.type = "button";
      deleteBtn.textContent = "Delete";
 
      deleteBtn.addEventListener("click", function () {
        tr.remove();
      });
 
      tdAction.appendChild(deleteBtn);
 
      tr.appendChild(tdName);
      tr.appendChild(tdEmail);
      tr.appendChild(tdAction);
 
      bookingTable.appendChild(tr);
 
      // Clear fields + focus
      studentName.value = "";
      studentEmail.value = "";
      studentName.focus();
    });
  });