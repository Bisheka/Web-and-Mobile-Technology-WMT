

const minAge = 18;


let students = [];


function submitForm() {

 
    let name = document.getElementById("name").value;
    let age = Number(document.getElementById("age").value);
    let email = document.getElementById("email").value;
    let phone = document.getElementById("phone").value;

  
    switch (true) {

        case (name === "" || email === ""):
            alert("Validation failed: Empty fields");
            return false;

        case (age < minAge):
            alert("Validation failed: Age below 18");
            return false;

        case (phone.length !== 10 || isNaN(phone)):
            alert("Validation failed: Phone number must be at least 10 digits");
            return false;

        default:
            alert(
                "Student Details:\n" +
                "Name: " + name + "\n" +
                "Age: " + age + "\n" +
                "Email: " + email + "\n" +
                "Phone: " + phone
            );
    }

    // Create student object
    let student = {
        name: name,
        age: age,
        email: email,
        phone: phone
    };


    students.push(student);

    console.clear();
    for (let i = 0; i < students.length; i++) {
        console.log(
            "Name: " + students[i].name +
            ", Age: " + students[i].age +
            ", Email: " + students[i].email +
            ", Phone: " + students[i].phone
        );
    }

    // Clear form fields
    document.getElementById("name").value = "";
    document.getElementById("age").value = "";
    document.getElementById("email").value = "";
    document.getElementById("phone").value = "";

   
    document.getElementById("name").focus();

    return false;
}
  let title = document.getElementById("title"); 
  let image = document.images[0];
  let form  = document.forms[0];

 window.onload = function () {
    console.log("Page URL:", document.URL);
    console.log("Last Modified:", document.lastModified);
    document.title = "Travel Adventures - DOM Lab";
};

    title.style.color = "darkblue";
    title.style.fontSize = "36px";
    title.style.fontFamily = "Arial";


setTimeout(function () {
    document.body.style.backgroundColor = "#5490cf";
}, 2000);

image.onmouseover = function () {
    image.style.border = "5px solid orange";
};

image.onmouseout = function () {
    image.style.border = "none";
};

document.getElementById("name").onkeyup = function () {
    this.style.backgroundColor = "red";
};
form.onsubmit = function (event) {
    event.preventDefault();
    addTraveler();
};
function addTraveler() {

    let name = document.getElementById("name").value;
    let age = document.getElementById("age").value;
    let email = document.getElementById("email").value;

    let table = document.getElementById("travelerTable");
    let row = table.insertRow();

    row.insertCell(0).innerText = name;
    row.insertCell(1).innerText = age;
    row.insertCell(2).innerText = email;

    let deleteCell = row.insertCell(3);
    let btn = document.createElement("button");
    btn.innerText = "Delete";

    btn.onclick = function () {
        table.deleteRow(row.rowIndex);
    };

    deleteCell.appendChild(btn);

    form.reset();
}
let costTable = document.getElementById("costTable");

costTable.addEventListener("click", function () {
    alert("You clicked on the Trip cost table!");
});

let img1 = new Image();
let img2 = new Image();

img1.src = "./image/image_1.png"; 
img2.src = "./image/image_2.jpeg"; 

let showingSecond = false;

image.onclick = function () {
  image.src = showingSecond ? img1.src : img2.src;
  showingSecond = !showingSecond;
};

window.onresize = function () {
    console.log("Window resized");
};