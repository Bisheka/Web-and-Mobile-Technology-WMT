
// Lab 3 

const minAge = 18;
let students = [];


function isValidPhone(phone) {
  return /^\d{10}$/.test(phone);
}
function isValidEmail(email) {
  return email.includes("@") && email.includes(".");
}



function submitForm() {
  let name = document.getElementById("name").value.trim();
  let age = Number(document.getElementById("age").value);
  let email = document.getElementById("email").value.trim();
  let phone = document.getElementById("phone").value.trim();

  switch (true) {
    case (name === "" || email === "" || phone === ""):
      alert("Validation failed: Empty fields");
      return false;

    case (age < minAge):
      alert("Validation failed: Age below 18");
      return false;

    case (!isValidEmail(email)):
      alert("Validation failed: Invalid email");
      return false;

    case (!isValidPhone(phone)):
      alert("Validation failed: Phone number must be exactly 10 digits");
      return false;

    default:
      alert(
        "Student Details:\n" +
        "Name: " + name + "\n" +
        "Age: " + age + "\n" +
        "Email: " + email + "\n" +
        "Phone: " + phone
      );
  }


  students.push({ name, age, email, phone });

  console.clear();
  students.forEach(s =>
    console.log(`Name: ${s.name}, Age: ${s.age}, Email: ${s.email}, Phone: ${s.phone}`)
  );


  addTraveler(name, age, email, phone);

 
  document.forms[0].reset();
  document.getElementById("name").focus();

  return false; 
}


// Lab 4 
window.onload = function () {
  const title = document.getElementById("title");
  const image = document.images[0];
  const costTable = document.getElementById("costTable");
  const travelerTable = document.getElementById("travelerTable");

  const nameInput = document.getElementById("name");
  const ageInput = document.getElementById("age");
  const emailInput = document.getElementById("email");
  const phoneInput = document.getElementById("phone");
  const submitBtn = document.getElementById("submitBtn");
  const ageFilter = document.getElementById("ageFilter");

  // Document properties
  console.log("Page URL:", document.URL);
  console.log("Last Modified:", document.lastModified);
  document.title = "Travel Adventures - DOM Lab";

  // Title style
  if (title) {
    title.style.color = "darkblue";
    title.style.fontSize = "36px";
    title.style.fontFamily = "Arial";
  }

  // Background after 2 seconds
  setTimeout(function () {
    document.body.style.backgroundColor = "#5490cf";
  }, 2000);

  // Mouse events on image
  if (image) {
    image.onmouseover = function () {
      image.style.border = "5px solid orange";
    };
    image.onmouseout = function () {
      image.style.border = "none";
    };
  }

  // Keyboard feedback
  if (nameInput) {
    nameInput.onkeyup = function () {
      this.style.backgroundColor = "#ffff99";
    };
  }

  // addEventListener demo: click cost table
  if (costTable) {
    costTable.addEventListener("click", function () {
      alert("You clicked on the Trip cost table!");
    });
  }

  // Image preload + toggle on dblclick
  let img1 = new Image();
  let img2 = new Image();
  img1.src = "./image/image_1.png";
  img2.src = "./image/image_2.jpeg";

  let showingSecond = false;
  if (image) {
    image.ondblclick = function () {
      showingSecond = !showingSecond;
      image.src = showingSecond ? img2.src : img1.src;
    };
  }


  window.onresize = function () {
    console.log("Window resized");
  };

 
  // Lab 5
  const fieldset = document.querySelector("fieldset");
  if (fieldset) {
    const kids = fieldset.children;
    for (let i = 0; i < kids.length; i++) {
      if (kids[i].tagName === "INPUT" && kids[i].type !== "submit") {
        kids[i].style.backgroundColor = "#eef";
      }
    }
  }

  //Counter

  const countPara = document.createElement("p");
  countPara.id = "travelerCount";
  countPara.innerText = "Total Registered Travelers: 0";

  if (travelerTable) {
    travelerTable.parentNode.insertBefore(countPara, travelerTable);
  }

  function updateCount() {
    if (!travelerTable) return;
    let count = travelerTable.rows.length - 1;
    if (count < 0) count = 0;
    countPara.innerText = "Total Registered Travelers: " + count;
  }

  updateCount();

  //Real-time validation 

  function validateLive() {
    if (!submitBtn) return;

    const nameOk = nameInput.value.trim() !== "";
    const ageOk = ageInput.value.trim() !== "" && Number(ageInput.value) >= 0;
    const emailOk = isValidEmail(emailInput.value.trim());
    const phoneOk = isValidPhone(phoneInput.value.trim());

    nameInput.classList.toggle("error", !nameOk);
    ageInput.classList.toggle("error", !ageOk);
    emailInput.classList.toggle("error", !emailOk);
    phoneInput.classList.toggle("error", !phoneOk);

    submitBtn.disabled = !(nameOk && ageOk && emailOk && phoneOk);
  }

  if (nameInput) nameInput.addEventListener("keyup", validateLive);
  if (ageInput) ageInput.addEventListener("keyup", validateLive);
  if (emailInput) emailInput.addEventListener("keyup", validateLive);
  if (phoneInput) phoneInput.addEventListener("keyup", validateLive);
  validateLive();

  // Event delegation delete

  if (travelerTable) {
    travelerTable.addEventListener("click", function (e) {
      if (e.target.tagName === "BUTTON") {
        e.target.closest("tr").remove();
        updateCount();
      }
    });
  }

  //Filtering
  if (ageFilter && travelerTable) {
    ageFilter.onchange = function () {
      const filter = this.value;
      const rows = travelerTable.rows;

      for (let i = 1; i < rows.length; i++) {
        const rowAge = Number(rows[i].cells[1].innerText);
        rows[i].style.display = "table-row";

        if (filter === "under18" && rowAge >= 18) rows[i].style.display = "none";
        if (filter === "adult" && (rowAge < 18 || rowAge >= 60)) rows[i].style.display = "none";
        if (filter === "senior" && rowAge < 60) rows[i].style.display = "none";
      }
    };
  }

  window._updateCount = updateCount;
};


function addTraveler(name, age, email, phone) {
  const table = document.getElementById("travelerTable");
  if (!table) return;

  const row = table.insertRow();

  row.insertCell(0).innerText = name;
  row.insertCell(1).innerText = age;
  row.insertCell(2).innerText = email;
  row.insertCell(3).innerText = phone;

  // conditional styling
  if (age < 18) row.style.backgroundColor = "#fff3cd";
  else if (age >= 60) row.style.backgroundColor = "#d1ecf1";

  // Delete button
  const actionCell = row.insertCell(4);
  const btn = document.createElement("button");
  btn.innerText = "Delete";
  actionCell.appendChild(btn);

  if (window._updateCount) window._updateCount();
}